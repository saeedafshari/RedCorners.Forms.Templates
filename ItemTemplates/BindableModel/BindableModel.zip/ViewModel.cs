﻿using System;
using System.Text;
using System.Linq;
using RedCorners.Forms;
using RedCorners.Models;
using System.Collections.Generic;
using Xamarin.Forms;

namespace $rootnamespace$
{
    public class $safeitemname$ : BindableModel
    {
        public $safeitemname$()
        {
            Status = TaskStatuses.Success;
        }
    }
}
