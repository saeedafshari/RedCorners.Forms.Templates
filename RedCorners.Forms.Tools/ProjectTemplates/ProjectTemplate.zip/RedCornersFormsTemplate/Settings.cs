﻿using System;
using System.Collections.Generic;
using System.Text;

namespace $safeprojectname$
{
    public partial class Settings
    {
        // Store global settings here.

        public int Count { get; set; }
    }
}
