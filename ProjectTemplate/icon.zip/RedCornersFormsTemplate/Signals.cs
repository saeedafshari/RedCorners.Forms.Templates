﻿using System;
using System.Collections.Generic;
using System.Text;

namespace $safeprojectname$
{
    public enum Signals
    {
        SaveSettings
    }
}
